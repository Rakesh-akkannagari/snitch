import React from 'react'
import Breadcrums from '../breadcrum/Breadcrums'
const Men = () => {
  const product = all_product.find((e)=> e.id === Number(productId));

  return (

    <div>    <Breadcrums product={product}/>
    </div>
  )
}

export default Men